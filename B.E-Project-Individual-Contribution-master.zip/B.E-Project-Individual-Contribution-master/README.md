# B.E-Project-Individual-Contribution
Regarding the individual research made within the allotted slot of project implementation
